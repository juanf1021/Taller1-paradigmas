let btnEntrar = document.getElementById('btn-entrar');
let inputCorreo = document.getElementById('input-correo');
let registerSection = document.getElementById('register');
let materiasSection = document.getElementById('materias');
let continuarBtn = document.getElementById('continuar');
let volverBtn = document.getElementById('volver');
let volverBtn1 = document.getElementById('volver1');
let volverBtn2 = document.getElementById('volver2');
let inscribirMen = document.getElementById('inscribirmen');
let cancelarMen = document.getElementById('cancelarmen');
let consultarMen = document.getElementById('consultarmen');

let inscribir = document.getElementById('inscribir');
let courseRegistration = document.getElementById('course-registration');
let courseCancel = document.getElementById('course-cancel');
let courseConsult = document.getElementById('course-consult');

let materias_derecho = [
  {
    "nombre": "Teoría del Poder",
    "tomado": false,
    "profesor": "John Smith",
    "aula": "A101",
    "creditos": 3
  },
  {
    "nombre": "Teoría del Estado",
    "tomado": false,
    "profesor": "Maria Garcia",
    "aula": "B202",
    "creditos": 4
  },
  {
    "nombre": "Teoría de la Constitución",
    "tomado": false,
    "profesor": "David Johnson",
    "aula": "C305",
    "creditos": 3
  },
  {
    "nombre": "Teoría de los derechos humanos",
    "tomado": false,
    "profesor": "Laura Martinez",
    "aula": "D404",
    "creditos": 3
  },
  {
    "nombre": "Fuentes del derecho constitucional",
    "tomado": false,
    "profesor": "Robert Brown",
    "aula": "E506",
    "creditos": 4
  },
  {
    "nombre": "División de poderes",
    "tomado": false,
    "profesor": "Emily White",
    "aula": "F607",
    "creditos": 3
  },
  {
    "nombre": "Control de constitucionalidad",
    "tomado": false,
    "profesor": "Daniel Lee",
    "aula": "G708",
    "creditos": 4
  }
];
let materias_diseno_moda = [
  {
    "nombre": "Historia de la Moda",
    "tomado": false,
    "profesor": "Anna Lopez",
    "aula": "H101",
    "creditos": 3
  },
  {
    "nombre": "Dibujo de Moda",
    "tomado": false,
    "profesor": "Carlos Ramirez",
    "aula": "I202",
    "creditos": 4
  },
  {
    "nombre": "Patronaje y Confección",
    "tomado": false,
    "profesor": "Elena Martinez",
    "aula": "J303",
    "creditos": 4
  },
  {
    "nombre": "Tecnología Textil",
    "tomado": false,
    "profesor": "David Johnson",
    "aula": "K404",
    "creditos": 3
  },
  {
    "nombre": "Diseño de Accesorios",
    "tomado": false,
    "profesor": "Maria Garcia",
    "aula": "L505",
    "creditos": 3
  },
  {
    "nombre": "Tendencias de Moda",
    "tomado": false,
    "profesor": "Laura Smith",
    "aula": "M606",
    "creditos": 3
  },
  {
    "nombre": "Marketing y Comunicación en Moda",
    "tomado": false,
    "profesor": "Daniel Lee",
    "aula": "N707",
    "creditos": 4
  }
];
let materias_ciencias_computacion = [
  {
    "nombre": "Introducción a la Programación",
    "tomado": false,
    "profesor": "Alice Johnson",
    "aula": "C101",
    "creditos": 4
  },
  {
    "nombre": "Estructuras de Datos",
    "tomado": false,
    "profesor": "Carlos Ramirez",
    "aula": "D202",
    "creditos": 3
  },
  {
    "nombre": "Algoritmos",
    "tomado": false,
    "profesor": "Elena Martinez",
    "aula": "E303",
    "creditos": 4
  },
  {
    "nombre": "Bases de Datos",
    "tomado": false,
    "profesor": "David Smith",
    "aula": "F404",
    "creditos": 3
  },
  {
    "nombre": "Inteligencia Artificial",
    "tomado": false,
    "profesor": "Maria Garcia",
    "aula": "G505",
    "creditos": 4
  },
  {
    "nombre": "Redes de Computadoras",
    "tomado": false,
    "profesor": "Robert Brown",
    "aula": "H606",
    "creditos": 3
  },
  {
    "nombre": "Seguridad Informática",
    "tomado": false,
    "profesor": "Laura Smith",
    "aula": "I707",
    "creditos": 3
  }
];


const materias_todas = [
  materias_derecho, materias_ciencias_computacion, materias_diseno_moda
];
let materias_inscritas = [];

let pasar = 0;
btnEntrar.addEventListener('click', () => {
  inputCorreo.value = "";
  inputCorreo.type = "password";
  inputCorreo.placeholder = "Password";
  pasar += 1;
  if (pasar >= 2) {
    materiasSection.style.display = 'block';
    registerSection.style.display = 'none';
  }
});

const carreraInput = document.getElementById('carrera');
let carrera = 0;
carreraInput.addEventListener('change', () => {
  carrera = parseInt(carreraInput.value);
});

continuarBtn.addEventListener('click', () => {
  materiasSection.style.display = 'none';
  inscribir.style.display = 'block';
});

const menu = document.getElementById('menu-regis');
const menuCancel = document.getElementById('menu-cancel');
const menuConsult = document.getElementById('menu-consult');
inscribirMen.addEventListener('click', () => {
  inscribir.style.display = 'none';
  courseRegistration.style.display = 'block';
  showSubjects(materias_todas[carrera], menu, cancelar = false)
});

cancelarMen.addEventListener('click', () => {
  inscribir.style.display = 'none';
  courseCancel.style.display = 'block';
  showSubjects(materias_todas[carrera], menuCancel, cancelar = true)
});

consultarMen.addEventListener('click', () => {
  inscribir.style.display = 'none';
  courseConsult.style.display = 'block';
  showSubjects(materias_todas[carrera], menuConsult, cancelar = true)
});


volverBtn.addEventListener('click', () => {
  inscribir.style.display = 'block';
  courseRegistration.style.display = 'none';
  courseCancel.style.display = 'none';
});

volverBtn1.addEventListener('click', () => {
  inscribir.style.display = 'block';
  courseRegistration.style.display = 'none';
  courseCancel.style.display = 'none';
});

volverBtn2.addEventListener('click', () => {
  inscribir.style.display = 'block';
  courseRegistration.style.display = 'none';
  courseConsult.style.display = 'none';
});

function showSubjects(subjects, menuSelected, cancelar) {
  menuSelected.innerHTML = '';
  for (let subject in subjects) {
    if (!cancelar) {
      if (subjects[subject].tomado == false) {
        createElements(subjects, subject, subjects[subject].tomado, menuSelected);
      };
    } else {
      if (subjects[subject].tomado == true) {
        createElements(subjects, subject, subjects[subject].tomado, menuSelected);
      }
    }
  };
};

function createElements(subjects, subject, tomado, menuSelected) {
  const menuDiv = document.createElement('div');
  menuDiv.id = subject;
  const h2 = document.createElement('h2');
  const button = document.createElement('button');
  h2.textContent = subjects[subject].nombre;
  button.textContent = tomado ? "Cancelar" : "Inscribir";
  button.dataset.value = parseInt(subject);
  button.addEventListener('click', handleButtonClick);
  menuDiv.classList.add('menu-div');
  menuSelected.appendChild(menuDiv);
  menuDiv.appendChild(h2);
  if (menuSelected.id == 'menu-consult') {
    const profesor = document.createElement('p');
    profesor.textContent = subjects[subject].profesor;
    const aula = document.createElement('p');
    aula.textContent = subjects[subject].aula;
    const creditos = document.createElement('p');
    creditos.textContent = `Creditos:${subjects[subject].creditos}`;
    menuDiv.appendChild(profesor);
    menuDiv.appendChild(aula);
    menuDiv.appendChild(creditos);
  } else {
    menuDiv.appendChild(button);
  };
};

function handleButtonClick(event) {
  const clickedButton = event.target;
  let materia = parseInt(clickedButton.dataset.value);
  materias_todas[carrera][materia].tomado = !materias_todas[carrera][materia].tomado;
  document.getElementById(`${materia}`).remove();
  console.log(materias_todas[carrera])
}; 